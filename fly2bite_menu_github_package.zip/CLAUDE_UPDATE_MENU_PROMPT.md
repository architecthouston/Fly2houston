# Claude Prompt — Update Fly2Bite Menus From GitHub Data

You are working in the Fly2Bite React app. I added a GitHub-ready menu data package to the repository. Use it to update the restaurant list and menu screens.

## Files to use

- `src/data/fly2biteMenuData.ts`
- `src/data/fly2biteMenuData.json`
- `public/assets/menu/`
- `fly2bite_all_restaurant_menus_for_claude.md`

## Main task

Update the Fly2Bite app so the restaurant and menu pages are driven by `fly2biteMenuData` instead of hardcoded menu items.

## Requirements

1. Keep the current Fly2Bite visual design: dark navy background, electric-blue accent, glass cards, iPhone/mobile-first layout, bottom navigation, and the current Gate C8 demo flow.
2. Include these restaurants in the restaurant list:
   - Starbucks — Terminal C near C2 — fastest coffee/drinks option.
   - Velvet Taco — Terminal C near C5 — popular tacos/bowls option.
   - Hugo’s Cocina — Terminal C near C8 for prototype demo — Mexican dishes. Prices are TBD because the airport menu photo did not show prices.
   - Chick-fil-A — Terminal C near C16 — best for on-time delivery.
3. When a passenger opens a restaurant, show categories as chips/tabs and render the correct menu items from the data file.
4. Every menu item card must show the local `imageUrl` thumbnail from `/public/assets/menu/...`.
5. Use the optimized local WebP images only. Do not use high-resolution website images and do not hotlink restaurant websites.
6. Images should be displayed as small thumbnails, around 56–80 px inside the menu card, with rounded corners or a rounded square container.
7. If an image fails to load, show a clean dark placeholder with the item name initials, but keep the layout consistent.
8. Show prices from `priceDisplay`. If `priceDisplay` is `TBD`, display `Price available at checkout` or `TBD`, not `$0.00`.
9. Show calories when available. If calories are missing, hide the calories line instead of showing null.
10. For Chick-fil-A, use entree pricing as the default item price, but preserve meal/entree pricing if the UI supports options.
11. For Velvet Taco boozy/alcohol items, keep them hidden by default or mark them as age-restricted. Do not include alcohol in the normal passenger food ordering flow unless the app has age verification and airport compliance logic.
12. Maintain the selected cart demo items for Chick-fil-A unless I ask to change them:
    - Chick-fil-A Chicken Sandwich
    - Chick-fil-A Nuggets — 8 ct
    - Chick-fil-A Lemonade
13. Do not redesign the whole app. Only connect the app to the menu data and improve the restaurant/menu components as needed.

## Suggested implementation

- Create or update a data import in the restaurant/menu screen:

```ts
import fly2biteMenuData from "../data/fly2biteMenuData";
```

- Use `fly2biteMenuData.restaurants` to render the restaurant cards.
- Use the selected restaurant `slug` or `id` to find the restaurant data.
- Use `restaurant.categories` for the category chips.
- Use `restaurant.items.filter(item => item.category === activeCategory)` for the menu item list.
- Use `item.imageUrl` in an `<img>` tag.

## Acceptance criteria

The app should show a passenger-friendly menu with small food/beverage pictures for each item, without increasing the project size with large images. The menu data must be easy to maintain from GitHub, and the UI must still look like the approved Fly2Bite airport delivery prototype.
