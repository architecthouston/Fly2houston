# Fly2Bite Menu Data Package

This package is ready to upload to GitHub and use with Claude to update the Fly2Bite restaurant/menu app.

## What is included

- `src/data/fly2biteMenuData.ts` — TypeScript export for React/Claude.
- `src/data/fly2biteMenuData.json` — same data in JSON format.
- `public/assets/menu/` — optimized local WebP thumbnails for menu cards.
- `fly2bite_all_restaurant_menus_for_claude.md` — combined Markdown menu reference.
- `CLAUDE_UPDATE_MENU_PROMPT.md` — prompt to give Claude.

## Size

- Original four Markdown menu files total: 102.8 KB (105,250 bytes).
- Combined Markdown file: 16.3 KB (16,725 bytes).
- Optimized image assets folder: 363.0 KB.
- Full package folder before ZIP: 524.5 KB.

## Image rule

Images are intentionally small WebP thumbnails for prototype use. They should show what the passenger is selecting but should not be high resolution.

Before any public release or production deployment, replace prototype/brand images with approved/licensed assets and connect final prices to POS or an approved menu source.
